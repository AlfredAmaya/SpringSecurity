package com.platzi.pizza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlatziPizzeriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
