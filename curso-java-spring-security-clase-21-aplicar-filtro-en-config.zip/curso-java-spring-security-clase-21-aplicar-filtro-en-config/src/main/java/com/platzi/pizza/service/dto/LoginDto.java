package com.platzi.pizza.service.dto;

import lombok.Data;

@Data
public class LoginDto {
    private String username;
    private String password;
}
