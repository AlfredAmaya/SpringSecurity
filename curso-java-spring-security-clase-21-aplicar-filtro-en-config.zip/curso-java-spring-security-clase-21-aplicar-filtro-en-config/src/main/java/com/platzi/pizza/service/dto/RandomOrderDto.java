package com.platzi.pizza.service.dto;

import lombok.Data;

@Data
public class RandomOrderDto {
    private String idCustomer;
    private String method;
}
